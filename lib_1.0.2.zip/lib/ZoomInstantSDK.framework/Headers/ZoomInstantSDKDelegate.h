//
//  ZoomInstantSDKDelegate.h
//  ZoomInstantSDK
//

#import <Foundation/Foundation.h>
#import "ZoomInstantSDKConstants.h"
#import "ZoomInstantSDKVideoRawData.h"
#import "ZoomInstantSDKAudioRawData.h"
#import "ZoomInstantSDKChatHelper.h"
#import "ZoomInstantSDKPreProcessRawData.h"
#import "ZoomInstantSDKVideoSender.h"
#import "ZoomInstantSDKVideoCapability.h"
#import "ZoomInstantSDKVideoHelper.h"
#import "ZoomInstantSDKAudioHelper.h"
#import "ZoomInstantSDKShareHelper.h"
#import "ZoomInstantSDKLiveStreamHelper.h"
#import "ZoomInstantSDKUserHelper.h"

@class ZoomInstantSDKUser;

@protocol ZoomInstantSDKDelegate <NSObject>
@optional
/*!
 @brief The callback of session join.
 */
- (void)onSessionJoin;

/*!
 @brief The callback of session left.
 */
- (void)onSessionLeave;

/*!
 @brief The callback of all event error message.
 @param ErrorType A enum of error
 @param details The detail of error message.
 */
- (void)onError:(ZoomInstantSDKERROR)ErrorType detail:(NSInteger)details;

/*!
 @brief The callback of user join session.
 @param userArray Array contain 'ZoomInstantSDKUser'.
 */
- (void)onUserJoin:(ZoomInstantSDKUserHelper *)helper users:(NSArray <ZoomInstantSDKUser *>*)userArray;

/*!
 @brief The callback of user left session.
 @param userArray Array contain userId.
 */
- (void)onUserLeave:(ZoomInstantSDKUserHelper *)helper users:(NSArray <ZoomInstantSDKUser *>*)userArray;

/*!
 @brief The callback of user's video status change.
 @param userArray Array contain userId.
 */
- (void)onUserVideoStatusChanged:(ZoomInstantSDKVideoHelper *)helper user:(NSArray <ZoomInstantSDKUser *>*)userArray;

/*!
 @brief The callback of user's audio status change.
 @param userArray Array contain userId.
 */
- (void)onUserAudioStatusChanged:(ZoomInstantSDKAudioHelper *)helper user:(NSArray <ZoomInstantSDKUser *>*)userArray;

/*!
 @brief The callback of user's share status change.
 @param status A enum of share status.
 */
- (void)onUserShareStatusChanged:(ZoomInstantSDKShareHelper *)helper user:(ZoomInstantSDKUser *)user status:(ZoomInstantSDKReceiveSharingStatus)status;

/*!
 @brief The callback of user's live stream status change.
 @param status A enum of live stream status.
 */
- (void)onLiveStreamStatusChanged:(ZoomInstantSDKLiveStreamHelper *)helper status:(ZoomInstantSDKLiveStreamStatus)status;

/*!
 @brief The callback of instant message in the session.
 @param chatMessage The object which contains the message content.
 */
- (void)onChatNewMessageNotify:(ZoomInstantSDKChatHelper *)helper message:(ZoomInstantSDKChatMessage *)chatMessage;

/*!
 @brief The callback of session's host change.
 */
- (void)onUserHostChanged:(ZoomInstantSDKUserHelper *)helper users:(ZoomInstantSDKUser *)user;

/*!
@brief The callback of session's manager change.
*/
- (void)onUserManagerChanged:(ZoomInstantSDKUser *)user;

/*!
@brief The callback of user's name change.
*/
- (void)onUserNameChanged:(ZoomInstantSDKUser *)user;

/*!
 @brief The callback of active audio change.
 @param userArray The active array of user's id.
 */
- (void)onUserActiveAudioChanged:(ZoomInstantSDKUserHelper *)helper users:(NSArray <ZoomInstantSDKUser *>*)userArray;

/*!
 @brief The callback of the session need password.
 */
- (void)onSessionNeedPassword:(ZoomInstantSDKERROR (^)(NSString *password, BOOL leaveSessionIgnorePassword))completion;

/*!
 @brief The callback of the session password wrong.
 */
- (void)onSessionPasswordWrong:(ZoomInstantSDKERROR (^)(NSString *password, BOOL leaveSessionIgnorePassword))completion;

/*!
 @brief This method is used to receive audio mixed raw data.
 @param rawData Audio's raw data.
 */
- (void)onMixedAudioRawDataReceived:(ZoomInstantSDKAudioRawData *)rawData;

/*!
 @brief This method is used to receive each road user audio raw data.
 @param rawData Audio's raw data.
 */
- (void)onOneWayAudioRawDataReceived:(ZoomInstantSDKAudioRawData *)rawData user:(ZoomInstantSDKUser *)user;
@end

#pragma mark - ZoomInstantSDKRawDataPipeDelegate
/*!
 @brief ZoomInstantSDKRawDataPipeDelegate, This class is used to receive video raw data.
 */
@protocol ZoomInstantSDKRawDataPipeDelegate <NSObject>

@optional

/*!
 @brief This method is used to receive video's NV12 data(CVPixelBufferRef).
 @param pixelBuffer Video's CVPixelBufferRef data.
 */
- (void)onPixelBuffer:(CVPixelBufferRef)pixelBuffer
             rotation:(ZoomInstantSDKVideoRawDataRotation)rotation;

/*!
 @brief This method is used to receive video's YUV420 data.
 @param rawData Video's YUV420 data.
 */
- (void)onRawDataFrameReceived:(ZoomInstantSDKVideoRawData *)rawData;

/*!
 @brief Callback event when the sender stop/start to sending raw data.
 @param userRawdataStatus Raw data is sending or not.
 */
- (void)onRawDataStatusChanged:(ZoomInstantSDKUserRawdataStatus)userRawdataStatus;

@end


/*!
 @brief Interface for modify default device capture raw data. @See ZoomInstantSDKSessionContext#preProcessor.
 */
@protocol ZoomInstantSDKVideoSourcePreProcessor <NSObject>

@optional
/*!
 @brief Callback on device capture video frame.
 @param rawData See ZoomInstantSDKPreProcessRawData
 */
- (void)onPreProcessRawData:(ZoomInstantSDKPreProcessRawData *)rawData;

@end

/*!
 @brief Custom external video source interface.
 */
@protocol ZoomInstantSDKVideoSource <NSObject>

@optional

/*!
 @brief Callback for video source prepare.
 @param rawDataSender See ZoomInstantSDKVideoSender
 @param supportCapabilityArray See ZoomInstantSDKVideoCapability
 @param suggestCapability See ZoomInstantSDKVideoCapability
 */
- (void)onInitialize:(ZoomInstantSDKVideoSender *_Nonnull)rawDataSender supportCapabilityArray:(NSArray *_Nonnull)supportCapabilityArray suggestCapability:(ZoomInstantSDKVideoCapability *_Nonnull)suggestCapability;

/*!
 @brief Callback for video size or fps changed.
 @param supportCapabilityArray See ZoomInstantSDKVideoCapability
 @param suggestCapability See ZoomInstantSDKVideoCapability
 */
- (void)onPropertyChange:(NSArray *_Nonnull)supportCapabilityArray suggestCapability:(ZoomInstantSDKVideoCapability *_Nonnull)suggestCapability;

/*!
 @brief Callback for video source can start send raw data.
 */
- (void)onStartSend;

/*!
 @brief Callback for video source  stop send raw data. eg.user mute video
 */
- (void)onStopSend;

/*!
 @brief Callback for video source uninitialized. eg.leave session.
 */
- (void)onUninitialized;

@end

