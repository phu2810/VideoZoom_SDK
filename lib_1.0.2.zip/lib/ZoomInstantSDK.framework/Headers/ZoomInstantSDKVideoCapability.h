//
//  ZoomInstantSDKVideoCapability.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2020/3/9.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZoomInstantSDKVideoCapability : NSObject

@property (nonatomic, assign) int width;

@property (nonatomic, assign) int height;

@property (nonatomic, assign) int frame;

@end
