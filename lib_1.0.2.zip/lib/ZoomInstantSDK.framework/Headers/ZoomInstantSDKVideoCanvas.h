//
//  ZoomInstantSDKVideoCanvas.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2018/12/7.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!
 @class ZoomInstantSDKVideoCanvas
 @brief The video canvas is the display area of the video streams on the user’s local device. To instantiate a local video canvas instance and show the video stream of a user, simply initialize the ZoomInstantSDKVideoCanvas object, subscribe the userId of a specific user, and add it to your UIView.
 */
@interface ZoomInstantSDKVideoCanvas : NSObject

/*!
 @brief Call the function to subscribe video or share data. You can subscribe your 'preview video' data with userid=0 before entering the session, you can just call it  after you called "joinSession:". Otherwise, you can subscribe video or share data using the real userid in callback "onUserJoin:".
 @param view the object of UIView, that's you need render video.
 @param aspect the video‘s aspect.
 @return The result of this method.
 */
- (ZoomInstantSDKERROR)subscribeWithView:(UIView *)view andAspectMode:(ZoomInstantSDKVideoAspect)aspect;

/*!
 @brief Call the function to unsubscribe video or share data.
 @return The result of the method.
 */
- (ZoomInstantSDKERROR)unSubscribeWithView:(UIView *)view;

@end
