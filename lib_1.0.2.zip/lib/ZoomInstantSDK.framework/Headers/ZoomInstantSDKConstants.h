//
//  ZoomInstantSDKConstants.h
//  ZoomInstantSDK
//
#ifndef ZoomInstantSDKConstants_h
#define ZoomInstantSDKConstants_h

/*!
 @brief ZoomInstantSDKERROR An enumeration of error.
 */
typedef NS_ENUM(NSUInteger,ZoomInstantSDKERROR)
{
    Errors_Success = 0,///<Success.
    Errors_Wrong_Usage,
    Errors_Internal_Error,
    Errors_Uninitialize,
    Errors_Memory_Error,
    Errors_Load_Module_Error,
    Errors_UnLoad_Module_Error,
    Errors_Invalid_Parameter,
    Errors_Unknown,
    Errors_Auth_Base = 1000,
    Errors_Auth_Error,
    Errors_Auth_Empty_Key_or_Secret,
    Errors_Auth_Wrong_Key_or_Secret,
    Errors_Auth_DoesNot_Support_SDK,
    Errors_Auth_Disable_SDK,
    Errors_Session_Base = 2000,
    Errors_Session_Module_Not_Found,
    Errors_Session_Service_Invaild,
    Errors_Session_Join_Failed,
    Errors_Session_No_Rights,
    Errors_Session_Already_In_Progress,
    Errors_Session_Dont_Support_SessionType,
    Errors_Session_Reconncting,
    Errors_Session_Disconncting,
    Errors_Session_Not_Started = 2010,
    Errors_Session_Need_Password,
    Errors_Session_Password_Wrong,
    Errors_Session_Remote_DB_Error,
    Errors_Session_Invalid_Param,
    Errors_Session_Audio_Error = 3000,
    Errors_Session_Video_Error = 4000,
    Errors_Session_Video_Device_Error,
    
    Errors_Session_Live_Stream_Error = 5000,
    
    Errors_Malloc_Failed = 6002,
    Errors_Not_In_Session = 6005,
    Errors_No_License,
    
    Errors_Video_Module_Not_Ready,
    Errors_Video_Module_Error,
    Errors_Video_device_error,
    Errors_No_Video_Data,
    
    Errors_Share_Module_Not_Ready,
    Errors_Share_Module_Error,
    Errors_No_Share_Data,
    
    Errors_Audio_Module_Not_Ready,
    Errors_Audio_Module_Error,
    Errors_No_Audio_Data,
};

/*!
 @brief ZoomInstantSDKAudioType An enumeration of audio type.
 */
typedef NS_ENUM(NSUInteger,ZoomInstantSDKAudioType) {
    ZoomInstantSDKAudioType_None   = 0,
    ZoomInstantSDKAudioType_VOIP,
    ZoomInstantSDKAudioType_Unknow,
};

/*!
 @brief ZoomInstantSDKVideoAspect An enumeration of video aspect.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKVideoAspect) {
    ///Original
    ZoomInstantSDKVideoAspect_Original         = 0,
    ///Full Filled
    ZoomInstantSDKVideoAspect_Full_Filled,
    ///Letter Box
    ZoomInstantSDKVideoAspect_LetterBox,
    ///Pan And Scan
    ZoomInstantSDKVideoAspect_PanAndScan,
};

/*!
 @brief ZoomInstantSDKVideoType An enumeration of video type.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKVideoType) {
    ///Video Camera Data
    ZoomInstantSDKVideoType_VideoData  = 1,
    ///Share Data
    ZoomInstantSDKVideoType_ShareData,
};

/*!
 @brief ZoomInstantSDKReceiveSharingStatus An enumeration of receive sharing status.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKReceiveSharingStatus) {
    ZoomInstantSDKReceiveSharingStatus_None = 0,
    ZoomInstantSDKReceiveSharingStatus_Start,
    ZoomInstantSDKReceiveSharingStatus_Pause,
    ZoomInstantSDKReceiveSharingStatus_Resume,
    ZoomInstantSDKReceiveSharingStatus_Stop,
};

/*!
 @brief ZoomInstantSDKLiveStreamStatus An enumeration of live stream status.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKLiveStreamStatus) {
    ZoomInstantSDKLiveStreamStatus_None = 1,
    ZoomInstantSDKLiveStreamStatus_InProgress,
    ZoomInstantSDKLiveStreamStatus_Connecting,
    ZoomInstantSDKLiveStreamStatus_FailedTimeout,
    ZoomInstantSDKLiveStreamStatus_StartFailed,
    ZoomInstantSDKLiveStreamStatus_Ended,
};

/*!
 @brief ZoomInstantSDKVideoRawDataFormat An enumeration of video raw data format.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKVideoRawDataFormat) {
    ZoomInstantSDKVideoRawDataFormatI420            = 1,
};

/*!
 @brief ZoomInstantSDKVideoRawDataRotation The direction of video.
 */
typedef NS_ENUM(NSInteger, ZoomInstantSDKVideoRawDataRotation) {
    /// video direction 0
    ZoomInstantSDKVideoRawDataRotationNone      = 1,
    /// video direction 90
    ZoomInstantSDKVideoRawDataRotation90,
    /// video direction 180
    ZoomInstantSDKVideoRawDataRotation180,
    /// video direction 270
    ZoomInstantSDKVideoRawDataRotation270,
};

/*!
 @brief ZoomInstantSDKVideoResolution An enumeration of video raw data resolution.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKVideoResolution) {
    /// video resolution 90
    ZoomInstantSDKVideoResolution_90,
    /// video resolution 180
    ZoomInstantSDKVideoResolution_180,
    /// video resolution 360
    ZoomInstantSDKVideoResolution_360,
    /// video resolution 720
    ZoomInstantSDKVideoResolution_720,
};

/*!
 @brief Rawdata memory mode.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKRawDataMemoryMode) {
    ZoomInstantSDKRawDataMemoryModeStack,
    ZoomInstantSDKRawDataMemoryModeHeap
};

/*!
 @brief user's rawdata status.
 */
typedef NS_ENUM(NSUInteger, ZoomInstantSDKUserRawdataStatus) {
    ZoomInstantSDKUserRawdataOn,
    ZoomInstantSDKUserRawdataOff
};

#endif /* ZoomInstantSDKConstants_h */
