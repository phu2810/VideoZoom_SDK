//
//  ZoomInstantSDKVideoHelper.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2018/12/6.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @class ZoomInstantSDKVideoHelper
 @brief Get object of ZoomInstantSDKVideoHelper to operate the audio action.
 */
@interface ZoomInstantSDKVideoHelper : NSObject

/*!
 @brief Start send video.
 @return the result of it.
 */
- (ZoomInstantSDKERROR)startVideo;

/*!
 @brief stop send video.
 @return the result of it.
 */
- (ZoomInstantSDKERROR)stopVideo;

/*!
 @brief rotate my video. When the device onConfigurationChanged.
 @return the result of it.
 @warning the function only for internal video source, it's not work for capture video source.
 */
- (BOOL)rotateMyVideo:(UIDeviceOrientation)rotation;

/*!
 @brief Set to Switch the camera of the current user in local device.
 */
- (void)switchCamera;

@end
