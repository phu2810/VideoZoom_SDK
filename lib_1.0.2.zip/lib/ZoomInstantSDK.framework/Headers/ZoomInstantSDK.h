//
//  ZoomInstantSDK.h
//  ZoomInstantSDK
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "ZoomInstantSDKUser.h"
#import "ZoomInstantSDKDelegate.h"
#import "ZoomInstantSDKConstants.h"
#import "ZoomInstantSDKAudioHelper.h"
#import "ZoomInstantSDKVideoHelper.h"
#import "ZoomInstantSDKUserHelper.h"
#import "ZoomInstantSDKVideoCanvas.h"
#import "ZoomInstantSDKRawDataPipe.h"
#import "ZoomInstantSDKShareHelper.h"
#import "ZoomInstantSDKLiveStreamHelper.h"
#import "ZoomInstantSDKChatHelper.h"

@interface ZoomInstantSDKInitParams : NSObject
/*!
 @brief [Required] The domain of ZoomInstantSDK.
 */
@property (nonatomic, copy) NSString * _Nullable domain;
/*!
 @brief [Optional] The Prefix of Log file name.
 */
@property (nonatomic, copy) NSString * _Nullable logFilePrefix;
/*!
 @brief [Optional] If you use screen share, you need create group id in your apple developer account, and setup here.
 */
@property (nonatomic, copy) NSString * _Nullable  appGroupId;
/*!
 @brief [Optional] enable/disable log of SDK. log path AppData/tmp
 */
@property (nonatomic, assign) BOOL                          enableLog;
/*!
 @brief [Optional] The video rawdata memory mode. Default is ZoomInstantSDKRawDataMemoryModeStack
 */
@property (nonatomic, assign) ZoomInstantSDKRawDataMemoryMode  videoRawdataMemoryMode;
/*!
 @brief [Optional] The share rawdata memory mode. Default is ZoomInstantSDKRawDataMemoryModeStack
 */
@property (nonatomic, assign) ZoomInstantSDKRawDataMemoryMode  shareRawdataMemoryMode;
/*!
 @brief [Optional] The audio rawdata memory mode. Default is ZoomInstantSDKRawDataMemoryModeStack
 */
@property (nonatomic, assign) ZoomInstantSDKRawDataMemoryMode  audioRawdataMemoryMode;
@end

/*!
 @class ZoomInstantSDKVideoOptions
 @brief The video option of join session
 */
@interface ZoomInstantSDKVideoOptions : NSObject

/*!
 @brief Local video on or off
 */
@property (assign, nonatomic) BOOL localVideoOn;

@end

/*!
 @class ZoomInstantSDKAudioOptions
 @brief The audio option of join session
 */
@interface ZoomInstantSDKAudioOptions : NSObject

/*!
 @brief Local audio connect or not
 */
@property (assign, nonatomic) BOOL connect;

/*!
 @brief Local audio mute or not
 */
@property (assign, nonatomic) BOOL mute;
@end

@interface ZoomInstantSDKSessionContext : NSObject
/*!
 @brief [Required] The Session Name.
 sessionName The string length must be less than 150.
 Supported character scopes are: Letters, numbers, spaces, and the following characters:
 "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", "{", "}", "|", "~", ","
 */
@property (nonatomic, copy) NSString * _Nullable sessionName;
/*!
 @brief [Optional] The Session Password.
 */
@property (nonatomic, copy) NSString * _Nullable sessionPassword;
/*!
 @brief [Required] The User Name.
 */
@property (nonatomic, copy) NSString * _Nullable userName;
/*!
 @brief [Required] The Token.
 */
@property (nonatomic, copy) NSString * _Nullable token;
/*!
 @brief [Optional] The Audio Option.
 */
@property (nonatomic, strong) ZoomInstantSDKAudioOptions * _Nullable audioOption;
/*!
 @brief [Optional] The Video Option.
 */
@property (nonatomic, strong) ZoomInstantSDKVideoOptions * _Nullable videoOption;

/*!
@brief [Optional] The Session external video source delegate.
*/
@property (nonatomic, assign) id<ZoomInstantSDKVideoSource> _Nullable externalVideoSourceDelegate;

/*!
@brief [Optional] The Session pre-processer delegate.
*/
@property (nonatomic, assign) id<ZoomInstantSDKVideoSourcePreProcessor> _Nullable preProcessorDelegate;
@end

/*!
@brief The Session audio statistic information
*/
@interface ZoomInstantSDKSessionAudioStatisticInfo : NSObject
@property(nonatomic, assign, readonly) NSInteger  sendFrequency; /// session send frequency
@property(nonatomic, assign, readonly) NSInteger  sendLatency; /// session send latency
@property(nonatomic, assign, readonly) NSInteger  sendJitter; /// session send jitter
@property(nonatomic, assign, readonly) CGFloat    sendPacketLossAvg; /// session send packet loss average value
@property(nonatomic, assign, readonly) CGFloat    sendPacketLossMax; ///session send packet loss max value

@property(nonatomic, assign, readonly) NSInteger  recvFrequency; /// session receive frequency
@property(nonatomic, assign, readonly) NSInteger  recvLatency; /// session receive latency
@property(nonatomic, assign, readonly) NSInteger  recvJitter; /// session receive jitter
@property(nonatomic, assign, readonly) CGFloat    recvPacketLossAvg; /// session receive packet loss average value
@property(nonatomic, assign, readonly) CGFloat    recvPacketLossMax; ///session receive packet loss max value
@end

/*!
@brief The Session video or share statistic information
*/

@interface ZoomInstantSDKSessionASVStatisticInfo : NSObject
@property(nonatomic, assign, readonly) NSInteger  sendFrameWidth; /// session send frame width
@property(nonatomic, assign, readonly) NSInteger  sendFrameHeight; /// session send frame height
@property(nonatomic, assign, readonly) NSInteger  sendFps; /// session send fps
@property(nonatomic, assign, readonly) NSInteger  sendLatency; /// session send latency
@property(nonatomic, assign, readonly) NSInteger  sendJitter; /// session send jitter
@property(nonatomic, assign, readonly) CGFloat    sendPacketLossAvg; /// session send packet loss average value
@property(nonatomic, assign, readonly) CGFloat    sendPacketLossMax; /// session send packet loss max value

@property(nonatomic, assign, readonly) NSInteger  recvFrameWidth; /// session receive frame width
@property(nonatomic, assign, readonly) NSInteger  recvFrameHeight; /// session receive frame height
@property(nonatomic, assign, readonly) NSInteger  recvFps; /// session receive fps
@property(nonatomic, assign, readonly) NSInteger  recvLatency; /// session receive latency
@property(nonatomic, assign, readonly) NSInteger  recvJitter; /// session receive jitter
@property(nonatomic, assign, readonly) CGFloat    recvPacketLossAvg; /// session receive packet loss average value
@property(nonatomic, assign, readonly) CGFloat    recvPacketLossMax; /// session receive packet loss max value
@end


/*!
 @brief Zoom instant SDK session.
 */
@interface ZoomInstantSDKSession : NSObject

/*!
@brief Get the session name.
*/
- (NSString * _Nullable)getSessionName;

/*!
@brief Get the session password
*/
- (NSString * _Nullable)getSessionPassword;

/*!
@brief Get the session host name
*/
- (NSString * _Nullable)getSessionHostName;

/*!
@brief Get the session host user object
*/
- (ZoomInstantSDKUser * _Nullable)getSessionHost;

/*!
@brief Get the session all user list
*/
- (NSArray <ZoomInstantSDKUser *>* _Nullable)getAllUsers;

/*!
@brief Get my self user object in session
*/
- (ZoomInstantSDKUser * _Nullable)getMySelf;

/*!
@brief Get the specify user object by userId in session password
@param userId The specify user's identity.
*/
- (ZoomInstantSDKUser * _Nullable)getUser:(NSString *_Nonnull)userId;

/*!
@brief Get the session audio statistic information.
*/
- (ZoomInstantSDKSessionAudioStatisticInfo * _Nullable)getSessionAudioStatisticInfo;

/*!
@brief Get the session video statistic information.
*/
- (ZoomInstantSDKSessionASVStatisticInfo * _Nullable)getSessionVideoStatisticInfo;
/*!
@brief Get the session share statistic information.
*/
- (ZoomInstantSDKSessionASVStatisticInfo * _Nullable)getSessionShareStatisticInfo;

@end

/*!
 @class ZoomInstantSDK
 @brief Initialize the class to acquire all the services.
 @warning Access to the class and all the other components of the LiteSDK by merging <ZoomInstantSDK/ZoomInstantSDK.h> into source code.
 @warning The user can only obtain SDK configuration by initializing the class.
 */
@interface ZoomInstantSDK : NSObject

/*!
 @brief The delegate of ZoomInstantSDK, all callback of receiving conversation events.
 */
@property (nullable, assign, nonatomic) id<ZoomInstantSDKDelegate> delegate;

/*!
 @brief Get single instance of ZoomInstantSDK.
 */
+ (ZoomInstantSDK * _Nullable)shareInstance;

/*!
 @brief Call the function to initialize LiteSDK.
 @warning The instance will be instantiated only once over the lifespan of the application.
 @param context Initialize the parameter configuration of the SDK, please See [ZoomInstantSDKInitParams]
 */
- (ZoomInstantSDKERROR)initialize:(ZoomInstantSDKInitParams * _Nonnull)context;

/*!
@brief Notify common layer that application will resign active. Call the systematical method and then call the appWillResignActive via applicationWillResignActive.
@warning It is necessary to call the method in AppDelegate "- (void)applicationWillResignActive:(UIApplication *)application".
*/
- (void)appWillResignActive;

/*!
 @brief Notify common layer that application did become active. Call the appDidBecomeActive via applicationDidBecomeActive.
 @warning It is necessary to call the method in AppDelegate "- (void)applicationDidBecomeActive:(UIApplication *)application".
 */
- (void)appDidBecomeActive;

/*!
 @brief Notify common layer that application did enter background. Call the appDidEnterBackgroud via applicationDidEnterBackground.
 @warning It is necessary to call the method in AppDelegate "- (void)applicationDidEnterBackground:(UIApplication *)application".
 */
- (void)appDidEnterBackgroud;

/*!
 @brief Notify common layer that application will terminate. Call the appWillTerminate via applicationWillTerminate.
 @warning It is necessary to call the method in AppDelegate "- (void)applicationWillTerminate:(UIApplication *)application".
 */
- (void)appWillTerminate;

/*!
 @brief Use it to join a session with parameters in a SDKSessionContext.See [SDKSessionContext]
 @param context The context which contains the parameters.
 @return The state of join session, started or failed.
 */
- (ZoomInstantSDKSession * _Nullable)joinSession:(ZoomInstantSDKSessionContext * _Nonnull)context;

/*!
 @brief Use it to leave session.
 @param end Yes means end session, otherwize means leave session.
 @warning only host can end session. You can get the isHost information from in-Session 'userInfo'.
 @return The result of it.
 */
- (ZoomInstantSDKERROR)leaveSession:(BOOL)end;

/*!
 @brief Use it to get session information.
 @return Session information See [SDKSessionInfo].
 */
- (ZoomInstantSDKSession * _Nullable)getSession;

/*!
 @brief Get whether it is in the session.
 @return Is in session or not.
 */
- (BOOL)isInSession;

/*!
 @brief Get the current SDK version.
 @return The version of SDK.
 */
- (NSString * _Nullable)getSDKVersion;

/*!
 @brief Get object of ZoomInstantSDKAudioHelper. See [ZoomInstantSDKAudioHelper].
 @return The object of ZoomInstantSDKAudioHelper.
 */
- (ZoomInstantSDKAudioHelper * _Nonnull)getAudioHelper;

/*!
 @brief Get object of ZoomInstantSDKVideoHelper. See [ZoomInstantSDKVideoHelper].
 @return The object of ZoomInstantSDKVideoHelper.
 */
- (ZoomInstantSDKVideoHelper * _Nonnull)getVideoHelper;

/*!
 @brief Get object of ZoomInstantSDKUserHelper. See [ZoomInstantSDKUserHelper].
 @return The object of ZoomInstantSDKUserHelper.
 */
- (ZoomInstantSDKUserHelper * _Nonnull)getUserHelper;

/*!
 @brief Get object of ZoomInstantSDKShareHelper. See [ZoomInstantSDKShareHelper].
 @return The object of ZoomInstantSDKShareHelper.
 */
- (ZoomInstantSDKShareHelper * _Nonnull)getShareHelper;

/*!
 @brief Get object of ZoomInstantSDKLiveStreamHelper. See [ZoomInstantSDKLiveStreamHelper].
 @return The object of ZoomInstantSDKLiveStreamHelper.
 */
- (ZoomInstantSDKLiveStreamHelper * _Nonnull)getLiveStreamHelper;

/*!
 @brief Get object of ZoomInstantSDKChatHelper. See [ZoomInstantSDKChatHelper].
 @return The object of ZoomInstantSDKChatHelper.
 */
- (ZoomInstantSDKChatHelper * _Nonnull)getChatHelper;

@end
