//
//  ZoomInstantSDKChatHelper.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2019/1/9.
//  Copyright © 2019 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @class ZoomInstantSDKChatMessage
 @brief The object of ZoomInstantSDKChatMessage that contains all the information for a message.
 */

@class ZoomInstantSDKUser;
@interface ZoomInstantSDKChatMessage : NSObject
/*!
 @brief The sender user.
 */
@property (nonatomic, strong) ZoomInstantSDKUser   *senderUser;

/*!
 @brief The receiver userId.
 */
@property (nonatomic, strong) ZoomInstantSDKUser   *receiverUser;

/*!
 @brief The message content.
 */
@property (nonatomic, strong) NSString     *content;
/*!
 @brief The message sent time in timestamp.
 */
@property (nonatomic, assign) long long    timeStamp;
/*!
 @brief The message is send to all user or not.
 */
@property (nonatomic, assign) BOOL         isChatToAll;
/*!
 @brief The message is send by me or not.
 */
@property (nonatomic, assign) BOOL         isSelfSend;

@end

/*!
 @class ZoomInstantSDKChatHelper
 @brief Get object of ZoomInstantSDKChatHelper to operate the instant message in session.
 */
@interface ZoomInstantSDKChatHelper : NSObject

/*!
 @brief Call the function to send a message to a specified user.
 @param user The user who you want to send message.
 @param content The content what you want to send.
 @return The result of it.
 */
- (ZoomInstantSDKERROR)SendChatToUser:(ZoomInstantSDKUser *)user Content:(NSString *)content;

/*!
 @brief Call the function to send a message to all users.
 @param content The content what you want to send.
 @return The result of it.
 */
- (ZoomInstantSDKERROR)SendChatToAll:(NSString *)content;

/*!
 @brief Call the function to check the chat feature is enable or not.
 @return Yes means enabled, Otherwise not disabled.
 */
- (BOOL)IsChatDisabled;

/*!
 @brief Call the function to check that private chats are not available.
 @return Yes means disabled, Otherwise enabled.
 */
- (BOOL)IsPrivateChatDisabled;

@end
