//
//  ZoomInstantSDKUserInfo.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2018/12/7.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZoomInstantSDKRawDataPipe.h"
#import "ZoomInstantSDKVideoCanvas.h"

@interface ZoomInstantSDKVideoStatisticInfo : NSObject
/*!
 @brief frame width
 */
@property (nonatomic, assign) NSInteger     width;
/*!
 @brief frame height
 */
@property (nonatomic, assign) NSInteger     height;
/*!
 @brief frame per second
 */
@property (nonatomic, assign) NSInteger     fps;
/*!
 @brief bits per second
 */
@property (nonatomic, assign) NSInteger     bps;

@end

@interface ZoomInstantSDKShareStatisticInfo : NSObject
/*!
 @brief frame width
 */
@property (nonatomic, assign) NSInteger     width;
/*!
 @brief frame height
 */
@property (nonatomic, assign) NSInteger     height;
/*!
 @brief frame per second
 */
@property (nonatomic, assign) NSInteger     fps;
/*!
 @brief bits per second
 */
@property (nonatomic, assign) NSInteger     bps;

@end

/*!
 @class ZoomInstantSDKVideoStatus
 @brief The user‘s video status
 */
@interface ZoomInstantSDKVideoStatus : NSObject
/*!
 @brief The user's video is on/off.
 */
@property (nonatomic, assign) BOOL          on;

@end

/*!
 @class ZoomInstantSDKVideoStatus
 @brief The user‘s video status
 */
@interface ZoomInstantSDKAudioStatus : NSObject
/*!
 @brief The user's audio is on/off.
 */
@property (nonatomic, assign) BOOL          isMuted;
/*!
 @brief The user is talking or not.
 */
@property (nonatomic, assign) BOOL          talking;
/*!
 @brief The user's audio type.
 */
@property (nonatomic, assign) ZoomInstantSDKAudioType  audioType;

@end

/*!
 @class ZoomInstantSDKShareStatus
 @brief The user‘s share status
 */
@interface ZoomInstantSDKShareStatus : NSObject
/*!
 @brief The user's share status.
 */
@property (nonatomic, assign) ZoomInstantSDKReceiveSharingStatus  sharingStatus;

@end

/*!
 @class ZoomInstantSDKUserInfo
 @brief The user‘s information.
 */
@interface ZoomInstantSDKUser : NSObject
/*!
 @brief The user's id.
 */
- (NSString *)getUserId;

/*!
 @brief The user's name.
 */
- (NSString *)getUserName;
/*!
 @brief The userId in custom system. Which pass in jwt token or in SDKSessionContext.customUserId
 */
- (NSString *)getCustomUserId;
/*!
 @brief The user is host or not.
 */
- (BOOL)isHost;
/*!
 @brief The user is Manager or not.
 */
- (BOOL)isManager;
/*!
 @brief The user video status.
 */
- (ZoomInstantSDKVideoStatus *)videoStatus;
/*!
 @brief The user Audio status.
 */
- (ZoomInstantSDKAudioStatus *)audioStatus;
/*!
 @brief The user share status.
 */
- (ZoomInstantSDKShareStatus *)shareStatus;
/*!
 @brief Get video statistic info.
 */
- (ZoomInstantSDKVideoStatisticInfo *)getVideoStatisticInfo;
/*!
 @brief Get share statistic info.
 */
- (ZoomInstantSDKShareStatisticInfo *)getShareStatisticInfo;
/*!
 @brief Get video pipe.
 */
- (ZoomInstantSDKRawDataPipe *)getVideoPipe;
/*!
 @brief Get share pipe.
 */
- (ZoomInstantSDKRawDataPipe *)getSharePipe;
/*!
 @brief Get video canvas.
 */
- (ZoomInstantSDKVideoCanvas *)getVideoCanvas;
/*!
 @brief Get share canvas.
 */
- (ZoomInstantSDKVideoCanvas *)getShareCanvas;

@end
