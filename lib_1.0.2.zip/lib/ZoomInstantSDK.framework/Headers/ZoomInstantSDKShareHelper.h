//
//  ZoomInstantSDKShareHelper.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2018/12/13.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @class ZoomInstantSDKShareHelper
 @brief Get object of ZoomInstantSDKShareHelper to operate share content.
 */
@interface ZoomInstantSDKShareHelper : NSObject

/*!
 @brief Share a content.
 @param view The view shared.
 @warning view, recommend to pass a single UIView's object, such as UIView, UIImageView or WKWebView.
 @warning It is not recommended to pass UIView after add subview WKWebView or UIImageView.
 @return The result of it
 */
- (ZoomInstantSDKERROR)startShareWithView:(UIView *)view;

/*!
 @brief Set to stop App share.
 @return The result of it
 */
- (ZoomInstantSDKERROR)stopShare;

/*!
 @brief Set lock App share.
 @return The result of it.
 @warning Only Host/Manger can call the function.
 */
- (ZoomInstantSDKERROR)lockShare:(BOOL)lock;

/*!
 @brief Check share is locked or not.
 @return The result of it.
 */
- (BOOL)isShareLocked;

/*!
 @brief Check you're sharing or not.
 @return The result of it
 */
- (BOOL)isSharingOut;

/*!
 @brief Check other is sharing or not.
 @return The result of it
 */
- (BOOL)isOtherSharing;

@end
