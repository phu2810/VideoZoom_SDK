//
//  ZoomInstantSDKAudioHelper.h
//  ZoomInstantSDK
//
//  Created by Zoom Video Communications on 2018/12/6.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZoomInstantSDK.h"

/*!
 @class ZoomInstantSDKShareStatus
 @brief Get object of ZoomInstantSDKAudioHelper to operate the audio action.
 */
@interface ZoomInstantSDKAudioHelper : NSObject

/*!
 @brief Start audio.
 @return the result of it
 */
- (ZoomInstantSDKERROR)startAudio;

/*!
 @brief stop audio.
 @return the result of it
 */
- (ZoomInstantSDKERROR)stopAudio;

/*!
 @brief Mute user audio by userId
 @return the result of it
 @warning If mute self use userid=0.
 @warning Only user who start the session can mute others audio..
 */
- (ZoomInstantSDKERROR)muteAudio:(ZoomInstantSDKUser *)user;

/*!
 @brief Unmute user audio by userId
 @return the result of it
 @warning If Unmute self use userid=0.
 @warning Only user who start the session can Unmute others audio..
 */
- (ZoomInstantSDKERROR)unmuteAudio:(ZoomInstantSDKUser *)user;

/*!
 @brief Call the function to subscribe audio rawdata.
 */
- (ZoomInstantSDKERROR)subscribe;

/*!
 @brief Call the function to unSubscribe audio rawdata.
 */
- (ZoomInstantSDKERROR)unSubscribe;

@end

